
public class MyInitials {

	public static void main(String[] args) {
		System.out.println();
		System.out.println(" M       M          M       M ");
		System.out.println(" M M   M M          M M   M M ");
		System.out.println(" M M   M M          M M   M M ");
		System.out.println(" M   M   M          M   M   M ");
		System.out.println(" M       M          M       M ");
		System.out.println(" M       M          M       M ");
		System.out.println(" M       M          M       M ");
		System.out.println();

	}
}
