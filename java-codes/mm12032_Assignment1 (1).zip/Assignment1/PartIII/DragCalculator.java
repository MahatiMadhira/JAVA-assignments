
public class DragCalculator {

	
	public static void main(String[] arguments) {
		double radius = 1.5;
		double rho = 1.2;
		double v0 = 15;
		double v1 = 25;
		double cd = 0.5;
		double A;
		double pi = Math.PI;
		double dragDifference = 0;
		A = pi * radius * radius;
		dragDifference = 0.5*cd*rho*A*((v1*v1) - (v0*v0));
		 System.out.println("The object's change in drag force after velocity changes from "
		 		+ v0 +
		" m/s to " + v1 + " m/s is " + dragDifference + " N");
	}
}