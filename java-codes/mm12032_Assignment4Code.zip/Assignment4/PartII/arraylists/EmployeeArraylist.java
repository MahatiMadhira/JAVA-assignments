package arraylists;
import java.util.ArrayList;
import java.util.Iterator;

import employees.*;

public class EmployeeArraylist {

	public static void main(String[] args) {
		// this ArrayList MUST be parameterized
		ArrayList <Employee> employeesArrayList = new ArrayList<>();
		Manager emp1 = new Manager("John Smith", 0, 100000.0, 0);
		Manager emp2 = new Manager("Bob Jones", 0, 80000, 1);
		Manager emp3 = new Manager("Raymond Jones", 0, 75000, 1);
		HourlyEmployee emp4 = new HourlyEmployee("Mahati Madhira", 2, 15, 25);
		HourlyEmployee emp5 = new HourlyEmployee("Manognya Madhira", 2, 15, 25);
		HourlyEmployee emp6 = new HourlyEmployee("Amuktha Kotamarthy", 2, 22, 30);
		HourlyEmployee emp7 = new HourlyEmployee("Chanakya Chowdary", 2, 22, 30);
		IndividualContributor emp8 = new IndividualContributor("Naveen Bhanu", 1, 55000, false);
		IndividualContributor emp9 = new IndividualContributor("Srinu Mallela", 1, 55000, false);
		IndividualContributor emp10 = new IndividualContributor("Anuj Satya", 1, 65000, true);
		IndividualContributor emp11 = new IndividualContributor("Jugal Praneeth", 1, 65000, true);
		
		
		employeesArrayList.add(emp1);
		employeesArrayList.add(emp2);
		employeesArrayList.add(emp3);
		employeesArrayList.add(emp4);
		employeesArrayList.add(emp5);
		employeesArrayList.add(emp6);
		employeesArrayList.add(emp7);
		employeesArrayList.add(emp8);
		employeesArrayList.add(emp9);
		employeesArrayList.add(emp10);
		employeesArrayList.add(emp11);
		
		
		double total_salary=0;
		int total_emp=0;
		double avg_sal=0;
		for(Employee e: employeesArrayList)
		{
			if(e instanceof HourlyEmployee)
			{
				total_emp++;
				total_salary += (((HourlyEmployee) e).getHourlyRate() * ((HourlyEmployee) e).getWeeklyHours());
				avg_sal=total_salary/total_emp;
			}
		}
			System.out.println("Average salary of Hourly Employees = "+avg_sal);
			
			HourlyEmployee fifteenAnHourTwentyFiveHoursEmployee = null;
			for(Employee e: employeesArrayList)
			{
				if(e instanceof HourlyEmployee)
				{
					if(((HourlyEmployee)e).getHourlyRate()==15 && ((HourlyEmployee)e).getWeeklyHours()==25)
					{
						fifteenAnHourTwentyFiveHoursEmployee = ((HourlyEmployee)e);
						break;
					}
				}
			}
			
				
				Iterator<Employee> it = employeesArrayList.iterator();
				while(it.hasNext())
				{
					Employee e = it.next();
					if(e instanceof HourlyEmployee)
					{
						if(fifteenAnHourTwentyFiveHoursEmployee.equals((HourlyEmployee)e))
							it.remove();
					}
				}
				
				for(Employee e: employeesArrayList)
				{
					System.out.println(e);
				}
				
		}
	

}
