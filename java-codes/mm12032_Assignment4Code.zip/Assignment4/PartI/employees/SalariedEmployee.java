package employees;

public class SalariedEmployee extends Employee {
	private Double annualSalary;
	public SalariedEmployee()
	{
		super();
	}
	
	public SalariedEmployee(String name, int managerId, double annualSalary)
	
	{
		super(name,managerId);
		this.annualSalary=annualSalary;
	}
	
	public double getAnnualSalary()
	{
		return annualSalary;
	}
	
	public void setAnnualSalary(double annualSalary)
	{
		this.annualSalary=annualSalary;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+" Annual Salary: "+annualSalary+"";
	}
	
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (!super.equals(obj))
	return false;
	if (getClass() != obj.getClass())
	return false;
	SalariedEmployee other = (SalariedEmployee) obj;
	if (annualSalary == null) {
	if (other.annualSalary != null)
	return false;
	} else if (!annualSalary.equals(other.annualSalary))
	return false;
	return true;
	}

}
