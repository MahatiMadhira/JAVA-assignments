package employees;

public class Inheritance {

	public static void main(String[] args) {
		
		HourlyEmployee emp1 = new HourlyEmployee("Mahati", 10, 27.50, 20);
		SalariedEmployee emp2 = new SalariedEmployee("Amuktha", 20, 90000.0);
		IndividualContributor emp3 = new IndividualContributor("Stuti", 30, 60000.0, false);
		Manager emp4 = new Manager("Komal", 20, 100000.0, 2);
		
		System.out.println(emp1.toString());
		System.out.println(emp2.toString());
		System.out.println(emp3.toString());
		System.out.println(emp4.toString());
		System.out.println("Id for Individual Contributor: "+emp3.getId());
		System.out.println("Executive Rank for Manager: "+emp4.getExecutiveRank());
		
	}

}
