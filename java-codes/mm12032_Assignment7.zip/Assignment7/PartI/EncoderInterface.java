import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

@SuppressWarnings("serial")
public class EncoderInterface extends JFrame implements KeyListener{
	
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JTextField t1 = new JTextField(10); // text field for input
	JTextField t2 = new JTextField(10); // text field for output
	JButton clear = new JButton("clear"); // button to clear contents of text fields 
	String[] options = {"Numeric", "ROT13"}; // array for storing labels of list
	JComboBox<Object> c1 = new JComboBox<Object>(options); // list to display options of encoding
	JMenuBar m = new JMenuBar(); // menu bar for adding menu items
	JMenu m1 = new JMenu("FILE"); // menu for FILE
	JMenuItem exit = new JMenuItem("EXIT"); // item in FILE menu

	
	public EncoderInterface() {
		setSize(500,200);
		c1.setEditable(false);
		clear.addActionListener(e -> {t1.setText(""); t2.setText("");}); // clear contents of both text fields
		// add components to panel
		p1.add(t1);
	    p1.add(c1);
	    p1.add(clear);
	    p2.add(t2);
	    //default frame close
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	    m1.add(exit);
	    exit.addActionListener(e -> {this.dispose();});
	    m.add(m1);
	    //set positions of panels in the frame
	    this.getContentPane().add(BorderLayout.NORTH, m);
	    this.getContentPane().add(BorderLayout.CENTER, p1);
	    this.getContentPane().add(BorderLayout.SOUTH, p2);
	    // read input from text field 1 char by char
	    t1.addKeyListener(new KeyAdapter() 
	      {
	    	  public void keyReleased(KeyEvent evt) 
	    	  {
	    		  t1Released(evt);
	    	  }
	      });
	}
	
	public void t1Released(KeyEvent evt)
    {
  	      String s = t1.getText(); // read t1 input
  	      String res = "";
	      
	      if(c1.getSelectedIndex()==0) //Numeric Encoding is selected
	      {
	  		for(int i=0;i<s.length();i++)
	  		{
	  		int x=(int) (s.charAt(i)-'a')+1;
	  		res+=x+".";

	  		}
	  		t2.setText(res);
	      }
	      
	      if(c1.getSelectedIndex()==1) //ROT13 encoding is selected
	      {
	  		for(int i=0;i<s.length();i++)
	  		{
	  		char ch=(char) (s.charAt(i)+13);
	  		if(ch>122)
	  		ch=(char) (ch-26);
	  		res+=ch;
	  		}
	  		t2.setText(res);

	      }
    }
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
			new EncoderInterface().setVisible(true);
			}
			});  
	      
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
