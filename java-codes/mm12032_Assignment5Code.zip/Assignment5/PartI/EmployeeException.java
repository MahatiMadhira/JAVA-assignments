public class EmployeeException extends Exception {

	EmployeeException(String employeeType)
	{
		super(employeeType);
	}
	

}
