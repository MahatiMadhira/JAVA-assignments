import java.io.*;
import java.util.Scanner;

import java.util.ArrayList;
import java.util.Arrays;

import vehicles.*;

public class ReadEmployeeFile {

	public static Employee createEmployee(String inString) throws EmployeeException, NumberFormatException, EmployeeException1{

		String[] inArray = inString.split(",");
		ArrayList<String> strList = new ArrayList<String>(
	            Arrays.asList(inArray));
		
		if(inArray[0].equals("IndividualContributor"))
		{
			IndividualContributor emp1 = new IndividualContributor(strList.get(1),Integer.parseInt(strList.get(2)),Double.parseDouble(strList.get(3)),Boolean.parseBoolean(strList.get(4)));
			return emp1;
		}
		
		if(inArray[0].equals("HourlyEmployee"))
		{
			HourlyEmployee emp2 = new HourlyEmployee(strList.get(1),Integer.parseInt(strList.get(2)),Double.parseDouble(strList.get(3)),Double.parseDouble(strList.get(4)));
			
			return emp2;
		}
		
		if(inArray[0].equals("Manager"))
		{
			Manager emp3 = new Manager(strList.get(1),Integer.parseInt(strList.get(2)),Double.parseDouble(strList.get(3)),Integer.parseInt(strList.get(4)));
			
			return emp3;
		}
		
		else
		{
			throw new EmployeeException("Employee type is not Individual, Hourly or Manager!");
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException, NumberFormatException, EmployeeException1{
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		File f = new File("employees.txt");
		String inString = null;
		
		try
		{
			FileInputStream fis=new FileInputStream(f);
			Scanner sc=new Scanner(fis);
			while(sc.hasNextLine()){
				inString = sc.nextLine(); 
				try {
					Employee emp = createEmployee(inString);
					employeeList.add(emp);
				}
				catch(EmployeeException e)
				{
					System.err.println(e);
				}
				
			}
				sc.close();
				fis.close();
		}catch (IOException e){
			System.err.println("File Cannot be found: " + f);
		}

			System.out.println(employeeList);
		
	}
}
