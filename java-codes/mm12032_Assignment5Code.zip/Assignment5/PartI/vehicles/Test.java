package vehicles;

import vehicles.HourlyEmployee;
import vehicles.IndividualContributor;
import vehicles.Manager;
import vehicles.SalariedEmployee;

public class Test {
	public static void main(String [] args)
	{
		
		try
		{
			HourlyEmployee emp1 = new HourlyEmployee("Mahati", 10, 6.50, 20);
		} catch (EmployeeException1 e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			HourlyEmployee emp2 = new HourlyEmployee("Amuktha", 10, 30.50, -1);
		} catch (EmployeeException1 e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			SalariedEmployee emp3 = new SalariedEmployee("Aayushi", 20, 14000.0);
		} catch(EmployeeException1 e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			Manager emp4 = new Manager("Komal", 20, 100000.0, -1);
		}catch(EmployeeException1 e)
		{
			System.out.println(e.getMessage());
		}
	}

}
