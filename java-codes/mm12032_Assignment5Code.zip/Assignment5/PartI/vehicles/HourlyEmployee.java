package vehicles;

public class HourlyEmployee extends Employee{
private Double hourlyRate;
private Double weeklyHours;

public HourlyEmployee()
{
	super();
}

public HourlyEmployee(String name, Integer managerId, double hourlyRate, double weeklyHours) throws EmployeeException1
{
	super(name,managerId);
	if(hourlyRate < 7.25)
		throw new EmployeeException1("Hourly rate cannot be less than minimum wage");
	this.hourlyRate=hourlyRate;
	if(weeklyHours < 0)
		throw new EmployeeException1("Weekly hours cannot be negative");
	this.weeklyHours=weeklyHours;
	
}


public double getHourlyRate() 
{
	return hourlyRate;
}

public void setHourlyRate(double hourlyRate) 
{
	this.hourlyRate=hourlyRate;
}

public double getWeeklyHours()
{
	
	return weeklyHours;
}

public void setWeeklyHours(double weeklyHours) 
{
	this.weeklyHours=weeklyHours;
}

@Override
public String toString()
{
	return "HourlyEmployee: ["+super.toString()+" hourly rate: "+hourlyRate+", weekly hours: "+weeklyHours+"]";
}

@Override
public boolean equals(Object obj) {
if (this == obj)
return true;
if (!super.equals(obj))
return false;
if (getClass() != obj.getClass())
return false;
HourlyEmployee other = (HourlyEmployee) obj;
if (hourlyRate == null) {
if (other.hourlyRate != null)
return false;
} else if (!hourlyRate.equals(other.hourlyRate))
return false;
if (weeklyHours == null) {
if (other.weeklyHours != null)
return false;
} else if (!weeklyHours.equals(other.weeklyHours))
return false;
return true;
}

}
