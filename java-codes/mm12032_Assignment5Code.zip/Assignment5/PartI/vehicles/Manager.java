package vehicles;


public class Manager extends SalariedEmployee{
	private Integer executiveRank;
	
	public Manager()
	{
		super();
	}
	
	public Manager(String name, int managerId,double annualSalary, int executiveRank) throws EmployeeException1
	{
		super(name,managerId,annualSalary);
		if(executiveRank <0)
			throw new EmployeeException1("Executive Rank for a manager cannot be negative");
		this.executiveRank=executiveRank;
	}
	
	public int getExecutiveRank()
	{
		return executiveRank;
	}
	
	public void setExecutiveRank(int executiveRank)
	{
		this.executiveRank=executiveRank;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+" executve rank: "+executiveRank+"";
	}
	
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (!super.equals(obj))
	return false;
	if (getClass() != obj.getClass())
	return false;
	Manager other = (Manager) obj;
	if (executiveRank == null) {
	if (other.executiveRank != null)
	return false;
	} else if (!executiveRank.equals(other.executiveRank))
	return false;
	return true;
	}
	
}
