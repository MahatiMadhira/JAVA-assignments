package vehicles;

public class Employee {
	private String name;
	private Integer managerId;
	private static int next_id;
	private int id;
	
	public Employee()
	{
		next_id++;
		id = next_id;
	}
	
	public Employee(String name, int managerId)
	{
		this.name=name;
		this.managerId=managerId;
		next_id++;
		id = next_id;
		
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public int getManagerId()
	{
		return managerId;
	}
	
	public void setManagerId(int managerId)
	{
		this.managerId=managerId;
	}
	
	public int getId()
	{
		return id;
	}
	@Override
	public String toString()
	{
		return "Name: "+name+", Manager ID: "+managerId+", ID: "+id;
	}
	
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (obj == null)
	return false;
	if (getClass() != obj.getClass())
	return false;
	Employee other = (Employee) obj;
	if (name == null) {
	if (other.name != null)
	return false;
	} else if (!name.equals(other.name))
	return false;
	if (id != other.id)
	return false;
	if (managerId == null) {
	if (other.managerId != null)
	return false;
	} else if (!managerId.equals(other.managerId))
	return false;
	return true;
	}
}
