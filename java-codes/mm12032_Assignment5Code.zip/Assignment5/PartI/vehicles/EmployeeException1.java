package vehicles;
public class EmployeeException1 extends Exception {

	EmployeeException1(String employeeType)
	{
		super(employeeType);
	}
	

}
