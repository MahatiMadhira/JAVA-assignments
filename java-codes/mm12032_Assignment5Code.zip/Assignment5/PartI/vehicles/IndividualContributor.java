package vehicles;


public class IndividualContributor extends SalariedEmployee {
	private Boolean senior;
	
	public IndividualContributor()
	{
		super();
	}
	
	public IndividualContributor(String name, int managerId, double annualSalary, boolean senior) throws EmployeeException1
	{
		super(name,managerId,annualSalary);
		this.senior=senior;
	}
	
	public boolean isSenior()
	{
		return senior;
	}
	
	public void setSenior(boolean senior)
	{
		this.senior=senior;
	}
	
	@Override
	public String toString()
	{
		return super.toString()+" Seniority: "+senior+"";
	}
	
	@Override
	public boolean equals(Object obj) {
	if (this == obj)
	return true;
	if (!super.equals(obj))
	return false;
	if (getClass() != obj.getClass())
	return false;
	IndividualContributor other = (IndividualContributor) obj;
	if (senior != other.senior)
	return false;
	return true;
	}

}

