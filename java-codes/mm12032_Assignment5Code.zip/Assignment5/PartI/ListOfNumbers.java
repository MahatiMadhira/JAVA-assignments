import java.io.*;
import java.util.List;
import java.util.ArrayList;
 
public class ListOfNumbers {
	
    private ArrayList <Pair> pairList;
    private String fileName;
 
    public ListOfNumbers () {
    	pairList = new ArrayList<Pair>();
    	this.fileName="";
    }
    
    public ArrayList getPairList() {
    	return this.pairList;
    }
    
    public void createList() {
    	for (int i = 0 ; i< 100 ; i++) {
    		Integer number1 = (int) (Math.random()*10000);
    		Integer number2 = (int) (Math.random()*10000);
    		Pair pair = new Pair(number1,number2);
    		pairList.add(pair);
    		
    	}
    }
    

    public ListOfNumbers (String fileName) {
    	this();
    	this.fileName = fileName;	
    	pairList = new ArrayList<Pair>();
    }
    
    public void readList() {
    	File f = new File("numberfile.txt");
    	InputStreamReader inputSt = null;
    	try
    	{
    		inputSt = new InputStreamReader (new FileInputStream(f));
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	
    	BufferedReader br = new BufferedReader(inputSt);
    	String l = "";
    	try 
    	{
    		while ((l = br.readLine()) != null) 
    		{
    			String data[]=l.split(" ");

    			this.pairList.add(new Pair(Integer.parseInt(data[0]),Integer.parseInt(data[1])));
    		}
    	} catch (IOException e) {
    	e.printStackTrace();
    	}
    }
    
    public void writeList() {
        PrintWriter out = null;
        try {
            System.out.println("Entering try statement");
            out = new PrintWriter(new FileWriter(this.fileName));
            for (int i = 0; i < pairList.size(); i++)
                out.println(pairList.get(i).getKey() + " " + pairList.get(i).getValue());
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Caught IndexOutOfBoundsException: " +
                                 e.getMessage());
        } catch (IOException e) {
            System.err.println("Caught IOException: " + e.getMessage());
        } finally {
            if (out != null) {
                System.out.println("Closing PrintWriter");
                out.close();
            } else {
                System.out.println("PrintWriter not open");
            }
        }
    }
    
    public static void cat(String fileName) throws FileNotFoundException, IOException{
        RandomAccessFile input = null;
        String line = null;
        File file = new File(fileName);
        try {
            input = new RandomAccessFile(file, "r");
            while ((line = input.readLine()) != null) {
                System.out.println(line);
            }
            return;
        } finally {
            if (input != null) {
                input.close();
            }
        }
    }
    
    public static void main(String[] args) throws IOException{
    	ListOfNumbers listOfNumbers = new ListOfNumbers("numberfile.txt");
    	ListOfNumbers.cat("numberfile.txt");
    	listOfNumbers.readList();
    }

}
