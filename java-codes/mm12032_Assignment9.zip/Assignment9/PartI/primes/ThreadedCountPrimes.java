package primes;

import java.util.HashSet;
import java.util.Set;

public class ThreadedCountPrimes implements Runnable {
	private long min;
	private long max;
	private long count;
	
	public ThreadedCountPrimes(long min, long max) {
		this.min = min;
		this.max = max;
		count = 0;
	}

	@Override
	public void run() {
		for (long i = min; i < max; i++) {
            if (CountPrimes.isPrime(i)) {
                count++;
            }
        }
		
	}
	
	public long getCount() {
        return count;
    }
	
	public static void main(String[] args) {

		long min = 10_000_000;
		long max = 20_000_000;
		
		long startTime = System.currentTimeMillis();
		long numPrimes = CountPrimes.numPrimes(min, max);

		long endTime = System.currentTimeMillis();
		System.out.println("number of primes from "+ min + " to " + max + " is " + numPrimes);
		System.out.println("this took  " + (endTime - startTime) + " ms ");
		//System.exit(0);
		numPrimes = 0;
		Set<Thread> threadSet = new HashSet<Thread>();
		Set<ThreadedCountPrimes> primesSet = new HashSet<ThreadedCountPrimes>();
		
		startTime = System.currentTimeMillis();
		
		int num=25;
		long interval = (max-min)/num;
		
		
		long curr_min = min;
		
		for(int i = 0;i<num;i++)
		{
			long curr_max = curr_min + interval;
			
			if(i==num-1)
				curr_max++;
		
		
		ThreadedCountPrimes t = new ThreadedCountPrimes(curr_min,curr_max);
		Thread thread = new Thread(t);
		threadSet.add(thread);
		primesSet.add(t);
		curr_min = curr_max;
		}
		
		for (Thread thread : threadSet) {
            thread.start();
        }
		
		
		for (Thread thread : threadSet) {
            try {
                thread.join();
            } catch (InterruptedException e) {}
        }
		
		for (ThreadedCountPrimes t : primesSet) {
            numPrimes += t.getCount();
        }
		
		endTime = System.currentTimeMillis();
		System.out.println("Threaded: number of primes from "+ min + " to " + max + " is " + numPrimes);
		System.out.println("this took  " + (endTime - startTime) + " ms ");

	}
}
