package binarytree;
import java.util.ArrayList;

import shapes.Circle;
import shapes.Rectangle;
import shapes.TwoDShape;

public class BinaryTree <E extends Comparable <E>>
{
	class Node <E extends Comparable <E>>
	{
		E val;
		Node<E> left_node;
		Node<E> right_node;
		Node<E> root = null;
		Node(E val)
		{
			this.val=val;
			right_node = null;
			left_node = null;
		}
	}
	
	private Node<E> root = null;
	public ArrayList<E> allNodes = new ArrayList<>();
	//method to add a value to the root node of Binary tree
	
	public void add(E val) {
		root = addIterate(root, val);
		allNodes.add(val);
	}
		
	//recursive method to iteratively traverse the Binary tree and check which position to add the new node to.
	private Node <E>addIterate(Node <E>cur, E val)
	{
		if(cur==null) return new Node<E>(val);
		if(cur.val.compareTo(val)<0) cur.right_node=addIterate(cur.right_node,val);
		else if(cur.val.compareTo(val)>0) cur.left_node=addIterate(cur.left_node,val);
		else return cur;
		
		return cur;
	}
	
	//method to check if the Binary tree is empty
	public boolean isEmpty() {
        return root == null;
    }
	
	//recursive method to iteratively search the Binary tree for a particular node.
	private boolean containsNodeIterate(Node <E>cur, E val)
	{
		if(cur==null) return false;
		if(cur.val.compareTo(val)==0) return true;
		
		return val.compareTo(val)<0
			      ? containsNodeIterate(cur.left_node, val)
			      : containsNodeIterate(cur.right_node, val);
	}

	//method to search the root of Binary Tree for a specific value.
	public boolean containsNode(E val)
	{
		return containsNodeIterate(root,val);
	}
	
	//method to delete a specific node from Binary Tree
	public void delete(E val) {
        root = deleteIterate(root, val);
    }

	//recursive method to iteratively traverse the tree and balance after deletion of a node.
    private Node<E> deleteIterate(Node<E> cur, E val) {
        if (cur == null) {
            return null;
        }

        if (val == cur.val) {
           
            if (cur.left_node == null && cur.right_node == null) {
                return null;
            }

            
            if (cur.right_node == null) {
                return cur.left_node;
            }

            if (cur.left_node == null) {
                return cur.right_node;
            }

            E smallestValue = findSmallestValue(cur.right_node);
            cur.val = smallestValue;
            cur.right_node = deleteIterate(cur.right_node, smallestValue);
            
            return cur;
        }
        if (val.compareTo(val)<0) {
            cur.left_node = deleteIterate(cur.left_node, val);
            return cur;
        }

        cur.right_node = deleteIterate(cur.right_node, val);
        return cur;
    }
    
  //method to find the smallest of two children of a node to replace the root after deletion.
    private E findSmallestValue(Node<E> root) {
        return root.left_node == null ? root.val : findSmallestValue(root.left_node);
    }
	
    //method to print the nodes of Binary Tree in ascending order by Traversing in-order.
    public void traverseInOrder(Node<E> cur) {
        if (cur != null) {
            traverseInOrder(cur.left_node);
            System.out.println("Visited: "+cur.val);
            traverseInOrder(cur.right_node);
        }
        
//        public ArrayList<E> getAllNodes() {
//        	return allNodes;
//        }
        
    }
    
    //method to test the functionality of Binary Tree
    @SuppressWarnings("unchecked")
	public void test()
    {
    	Node<String> root_node = new Node<String>("");
    	System.out.println("Building tree with root value " + root_node.val);
    	addIterate((Node<E>)root_node,(E)"A");
    	addIterate((Node<E>)root_node,(E)"F");
    	addIterate((Node<E>)root_node,(E)"J");
    	addIterate((Node<E>)root_node,(E)"H");
    	addIterate((Node<E>)root_node,(E)"Z");
    	
    	System.out.print("\nTesting hasNode method by searching for node Z : ");
		System.out.println(containsNodeIterate((Node<E>)root_node,(E)"Z"));
		
		System.out.println("\nDeleting node F from Binary Tree");
		deleteIterate((Node<E>)root_node,(E)"F");
		
		System.out.println("\nAll Nodes of Binary Tree after deletion in Ascending order: \n");
		traverseInOrder((Node<E>)root_node);
		
		System.out.println("\nTesting hasNode method by searching for node K : ");
		System.out.println(containsNodeIterate((Node<E>)root_node,(E)"K"));
		
		
		System.out.println("\nAll nodes of Binary tree in Ascending Order: \n");
		traverseInOrder((Node<E>)root_node);
    	
    }

	public static void main(String[] args) {
		//This should work
		BinaryTree<String> b = new BinaryTree<String>();
		b.test();
		
		//This should not work
		//BinaryTree<Object> bt2 = new BinaryTree<Object>();
	}

	public void add(Rectangle rec1) {
		// TODO Auto-generated method stub
		
	}

	public void add(Circle cr) {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<E> getAllNodes() {
		// TODO Auto-generated method stub
		return allNodes;
	}

}

