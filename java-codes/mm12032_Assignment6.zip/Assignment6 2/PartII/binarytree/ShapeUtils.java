package binarytree;
import java.util.ArrayList;

import shapes.TwoDShape;
import shapes.Circle;
import shapes.Rectangle;

public class ShapeUtils {

	public static double averageArea(BinaryTree<? extends TwoDShape> bt) {
		@SuppressWarnings("unchecked")
		ArrayList<TwoDShape> nodes = (ArrayList<TwoDShape>) bt.getAllNodes();
		double result = nodes.stream().map((node) -> {
			return node.getArea();
		}).mapToDouble((val) -> val).average()
				.getAsDouble();
		
		return result;
	}
	
	public static void main(String[] args) {
		
		Rectangle rec1 = new Rectangle(10,20);
		Rectangle rec2 = new Rectangle(20,30);
		Circle cr = new Circle(10);
		
		BinaryTree<? extends TwoDShape> bt = new BinaryTree<TwoDShape>();
		bt.add(rec1);
		bt.add(rec2);
		bt.add(cr);
		System.out.println(averageArea(bt));
	}

}
