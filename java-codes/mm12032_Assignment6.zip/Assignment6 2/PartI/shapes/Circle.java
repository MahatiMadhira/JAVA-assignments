package shapes;

public class Circle extends GeometricObject implements Cloneable {
	private double radius;
	
	public Circle() {
		
	}
	
	public Circle(double radius) {
		this.radius = radius;		
	}
	
	public Circle (double radius, String color, boolean filled) {
		this.radius = radius;
		setColor(color);
		setFilled(filled);
	}
	
	public double getRadius() {
		return radius;
	}
	
	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getDiameter() {
		return 2*radius;
	}
	
	
	public void printCircle() {
		System.out.println("The circle with radius:  " + radius+ " was created on: "+getDateCreated());
	}
	
	@Override
	public double getArea() {
		return radius * radius * Math.PI;
	}
	
	@Override
	public double getPerimiter() {
		return 2*radius * Math.PI;
	}
	
	
	@Override
	public String toString() {
		return "The circle with radius:  " + radius+ " was created on: "+getDateCreated();
	}

}
