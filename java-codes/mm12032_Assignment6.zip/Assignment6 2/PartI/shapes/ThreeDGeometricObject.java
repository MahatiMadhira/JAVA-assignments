package shapes;

public interface ThreeDGeometricObject {
	double getVolume();
	double getSurfaceArea();

}
