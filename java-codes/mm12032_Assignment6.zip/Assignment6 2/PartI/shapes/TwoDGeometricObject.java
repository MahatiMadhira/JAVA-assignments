package shapes;

public interface TwoDGeometricObject {
	double getArea();
	double getPerimeter();
}
