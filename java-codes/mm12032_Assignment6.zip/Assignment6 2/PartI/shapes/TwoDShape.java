package shapes;

public abstract class TwoDShape extends Shape implements  TwoDGeometricObject{
		protected TwoDShape()
		{
			
		}
		
		protected TwoDShape(String color, boolean filled)
		{
			super(color, filled);
		}

}

