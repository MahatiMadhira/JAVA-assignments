package shapes;

public class Shape {
	private String color = "blue";
   	private boolean filled;
   	private java.util.Date dateCreated;
   	
   	protected Shape() {
       	dateCreated = new java.util.Date();
     	filled = false;
   	}
	 
   	protected Shape(String color, boolean filled) {
       	dateCreated = new java.util.Date();
       	setColor(color);
       	setFilled(filled);
   	}
   	
   	public String getColor() {
       return color;
   }
  
   public void setColor(String color) {
       this.color = color;
   }
  
   public boolean isFilled() {
       return filled;
   }
  
   public void setFilled(boolean filled) {
       this.filled = filled;
   }
  
   public java.util.Date getDateCreated() {
       return dateCreated;
   }
  
   @Override
   public String toString() {
       return "created on " + dateCreated + "\ncolor: " + color +
               " and filled: " + filled;
   }

}
