package shapes;

public abstract class ThreeDShape extends Shape implements  ThreeDGeometricObject
{
	protected ThreeDShape()
	{
		
	}
	
	protected ThreeDShape(String color, boolean filled)
	{
		super(color, filled);
	}
}
