package shapes;

public class TestShape
{
	public static void main (String[] args) 
	{
		Sphere s = new Sphere(10);
		Rectangle r = new Rectangle(10,15);
		Circle c = new Circle(10,"Black",true);
		Circle c1 = new Circle(20);
		Triangle t = new Triangle(4,7,10);
		System.out.println ("Area of Rectangle: " + r.getArea());
		System.out.println ("Perimeter of Triangle: " + t.getPerimeter());
		System.out.println ("Radius of circle: " + c1.getRadius());
		System.out.println ("Color of circle: " + c.getColor());
		System.out.println (s);
		System.out.println (t);
		System.out.println (r);
		System.out.println (c);
		
	}
}
