package shapes;

public class Sphere extends ThreeDShape
{
	private double radius;
  
    public Sphere(double radius) {
       	super();
       	this.radius = radius;      
   	}
   	
   	public Sphere(double radius, String color, boolean filled) {
       	super(color, filled);
       	this.radius = radius;      
   	}
   	
   	public double getRadius() {
       return radius;
   }
  
   public void setRadius(double radius) {
       this.radius = radius;
   }
  
   public void printSphere() {
       System.out.println("The sphere with radius: " + radius+" was created on: "+getDateCreated());
   }
  
   @Override
   public double getSurfaceArea() {
       return 4 * radius * radius * Math.PI;
   }
  
   @Override
   public double getVolume() {
       return 4 * Math.PI * radius * radius * radius / 3;
   }
  
  
   @Override
   public String toString() {
       return "The sphere with radius: " + radius+" was created on: "+getDateCreated();
   }
}