package shapes;

public abstract class GeometricObject implements Comparable<GeometricObject> {
	
	private String color = "blue";
	private boolean filled;
	private java.util.Date dateCreated;
	
	protected GeometricObject() {
		dateCreated = new java.util.Date();
	}
	
	protected GeometricObject(String color, boolean filled) {
		dateCreated = new java.util.Date();
		this.color = color;
		this.filled = filled;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public boolean isFilled() {
		return filled;
	}
	
	public void setFilled(boolean filled) {
		this.filled = filled;
	}
	
	public java.util.Date getDateCreated() {
		return dateCreated;
	}
	
	@Override
	public String toString() {
		return "Shape with color: " + color+" is filled: " +filled + "and was created on: "+dateCreated;
	}
	
	public abstract double getArea();
	
	public abstract double getPerimiter();
	
	public int compareTo(GeometricObject o) {
		return Double.compare(this.getArea(), o.getArea());
	}
	
	public static void main(String[] args) {
		System.out.println(equalArea(new Rectangle(2,3), new Circle(5)));
	}
	
	public static <E extends GeometricObject> boolean equalArea(E object1, E object2) {
		return object1.getArea() == object2.getArea();
	}
		
}

