package PartIV;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class RollDice extends JFrame{
	
	int value;
	
	String[] images = {"die1.png", "die2.png", "die3.png", "die4.png", "die5.png", "die6.png"};
	
	JLabel l1 = new JLabel();
	JLabel l2 = new JLabel();
	JLabel sum_res = new JLabel();
	Dice dice1 = new Dice();
	Dice dice2 = new Dice();
	
	int sum;
	JButton roll;
	JPanel imgPanel;
    JPanel buttonPanel;
    JPanel resPanel;
    
    ImageIcon i1;
    ImageIcon i2;
	
	public RollDice() {
		setBounds(750, 700, 700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
		
        imgPanel = new JPanel();
        imgPanel.add(l1);
		imgPanel.add(l2);
		
        buttonPanel = new JPanel();
        roll = new JButton("Roll the Dice!");
		roll.addActionListener(new ButtonListener());
		buttonPanel.add(roll);
		
        resPanel = new JPanel();
        resPanel.add(sum_res);
        

		l1.addMouseListener(new MouseAdapter() {
			@Override
            public void mouseClicked(MouseEvent e) {
				dice1.roll();
				
				int v1 = dice1.getValue();
		        i1 = new ImageIcon(images[v1 - 1]);
		        l1.setIcon(i1);
		        sum = v1+dice2.getValue();

			    sum_res.setText("Result: "+sum);
            }

		});
		
		
		l2.addMouseListener(new MouseAdapter() {
			@Override
            public void mouseClicked(MouseEvent e) {
				dice2.roll();
				
				int v2 = dice2.getValue();
		        i2 = new ImageIcon(images[v2 - 1]);
		        l2.setIcon(i2);
		        sum = v2+dice1.getValue();

			    sum_res.setText("Result: "+sum);
            }

		});
		
		
		add(imgPanel, BorderLayout.NORTH);   
        add(buttonPanel, BorderLayout.SOUTH);
        add(resPanel,BorderLayout.CENTER);
	}
	
	private class ButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			
			dice1.roll();
			
			int v1 = dice1.getValue();
	        i1 = new ImageIcon(images[v1 - 1]);
	        l1.setIcon(i1);
	        
	        dice2.roll();
	        
	        int v2 = dice2.getValue();
	        i2 = new ImageIcon(images[v2 - 1]);
	        l2.setIcon(i2);
	        
	        sum = v1 + v2;
		    sum_res.setText("Result: "+sum);
	       
			
		}
	}
	
	public static void main(String[] args) {
		RollDice rollDice = new RollDice();
		rollDice.setVisible(true);
	
	}
}
	