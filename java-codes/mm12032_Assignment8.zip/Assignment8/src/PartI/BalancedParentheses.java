package PartI;

import java.util.Stack;

public class BalancedParentheses {

	public static boolean isBalanced(String inString) {
		Stack<Character> st = new Stack<>();
		boolean flag = true;
		char c;
		for(int i=0;i<inString.length() && flag;i++)
		{
			c=inString.charAt(i);
			if(c=='(') //can add code to check for '{' and '[' as well
			{
				st.push(c);
				continue;
			}
			if(c==')')
			{
				if(st.pop()!='(')
				{
					flag = false;
					break;
				}
			}
		}
		return st.isEmpty() && flag;
	}
	
	public static void main(String[] args) {
		boolean result = isBalanced("(()()()())");
		System.out.println(result);
		result = isBalanced("(((())))");
		System.out.println(result);
		result = isBalanced("((((((())");
		System.out.println(result);
	}
}
