package PartI;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

public class MyQueue<E> implements Queue<E> {
	
	private ArrayList<E> ar;
	 public MyQueue() {
	        ar = new ArrayList<E>();
	    }
	 
	 	@Override
	    public boolean isEmpty() {
	        return ar.isEmpty();
	    }

	    @Override
	    public int size() {
	        return ar.size();
	    }

	    @Override
	    public boolean offer(E e) {
	        return ar.add(e);
	    }

	    @Override
	    public E remove() {
	        if (isEmpty())
	            throw new NoSuchElementException();
	        return ar.remove(0);
	    }

	    @Override
	    public E poll() {
	        if (isEmpty())
	            return null;
	        return ar.remove(0);
	    }

	    @Override
	    public E element() {
	        if (isEmpty())
	            throw new NoSuchElementException();
	        return ar.get(0);
	    }

	    @Override
	    public E peek() {
	        if (isEmpty())
	            return null;
	        return ar.get(0);
	    }

	    public static void main(String[] args) {
	        MyQueue<String> q = new MyQueue<String>();
	        q.offer("mahati");
	        q.offer("bob");
	        q.offer("amuktha");
	        q.offer("darsh");
	        while (!q.isEmpty()) {
	            System.out.println(q.poll());
	        }
	        System.out.println(q.peek());
	        q.offer("chan");
	        System.out.println(q.peek());
	        q.poll();
	        q.offer("mannu");
	        System.out.println(q.peek());
	        
	        System.out.println("Element in first position is: "+q.element()); //throws exception since queue is empty
	        
	    }

	    @Override
	    public boolean contains(Object o) {
	        return false;
	    }

	    @Override
	    public Iterator<E> iterator() {
	        return null;
	    }

	    @Override
	    public Object[] toArray() {
	        return null;
	    }

	    @Override
	    public <T> T[] toArray(T[] a) {
	        return null;
	    }

	    @Override
	    public boolean add(E e) {
	        return false;
	    }

	    @Override
	    public boolean remove(Object o) {
	        return false;
	    }

	    @Override
	    public boolean containsAll(Collection<?> c) {
	        return false;
	    }

	    @Override
	    public boolean addAll(Collection<? extends E> c) {
	        return false;
	    }

	    @Override
	    public boolean removeAll(Collection<?> c) {
	        return false;
	    }

	    @Override
	    public boolean retainAll(Collection<?> c) {
	        return false;
	    }

	    @Override
	    public void clear() {
	    }
	

}
