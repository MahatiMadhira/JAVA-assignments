package PartI;
import java.util.ArrayList;
import java.util.EmptyStackException;


public class MyStack<E>{

	private ArrayList<E> ar;
	
	public MyStack()
	{
		ar = new ArrayList<E>();
	}
	
	public void push(E item)
	{
		ar.add(item);
	}
	
	public E pop()
	{
		if(ar.isEmpty())
			throw new EmptyStackException();
		else
			return ar.remove(ar.size()-1);
	}
	
	public E peek()
	{
		if(ar.isEmpty())
			throw new EmptyStackException();
		else
			return ar.get(ar.size()-1);
	}
	
	public int size()
	{
		return ar.size();
	}
	
	public E get(int i) {
		return ar.get(i);
		}
	
	public boolean empty()
	{
		return ar.isEmpty();
	}
	
	public int search(Object o)
	{
		for (int i=0;i<size();i++) 
		{
			if (get(i).equals(o)) 
				return (size()-i);
		}
		return -1;
	}
	
	public static void main(String[] args)
	{
		MyStack<Integer> st = new MyStack<>();
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
		st.push(60);
		st.push(73);
		
		System.out.println("Is stack empty? "+st.empty());
		System.out.println("Top of stack: "+st.peek());
		System.out.println("Adding new element 63 to stack: ");
		st.push(63);
		System.out.println("New Top of stack: "+st.peek());
		System.out.println("Searching for element 30. Index : "+st.search(30));
		System.out.println("Searching for element 90. Index : "+st.search(90));
		System.out.println("Removing elememt "+ st.pop()+" from Stack. ");
		System.out.println("New Top of stack: "+st.peek());
		
	}
	
}
