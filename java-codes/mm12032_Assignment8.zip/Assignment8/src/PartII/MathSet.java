package PartII;
import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("serial")
public class MathSet<E> extends HashSet<E> {

	public Set<E> intersection(Set<E> s2) {
		Set<E> res = new HashSet<>(this);
        res.retainAll(s2);
        return res;
	}
	
	public Set<E> union(Set<E> s2) {
		Set<E> res = new HashSet<>(this);
        res.addAll(s2);
        return res;

	}
	
	public <T> Set<Pair<E,T>> cartesianProduct(Set<T> s2) {
		Set<Pair<E,T>> res = new HashSet<>();
        for (E i1 : this) {
            for (T i2 : s2) {
                res.add(new Pair<>(i1, i2));
            }
        }
        return res;
		

	}
	
	public static void main(String[] args) {
		MathSet<Integer> set1 = new MathSet<>();
        MathSet<Integer> set2 = new MathSet<>();
        for (int i=1; i<=15; i++) {
            set1.add(2*i);
            set2.add((5*i)/2);
        }

        System.out.println("Set 1 = " + set1);
        System.out.println("Set 2 = " + set2);
        System.out.println("Union = " + set1.union(set2));
        System.out.println("Intersection = " + set1.intersection(set2));
        
        MathSet<String > set3 = new MathSet<>();
        set3.add("Good Morning");
        set3.add("Good Night");
       
        System.out.println("Cartesian product = ");
        System.out.println(set1.cartesianProduct(set3));
       

	}
}
