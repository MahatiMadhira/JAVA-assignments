package PartIII;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SortFrequency {

	public static void sortByFrequency(ArrayList<Integer> ar) {
		Map<Integer, Integer> sort_map = new HashMap<>();
		List<Integer> res = new ArrayList<>();
		for (int cur : ar) {
			sort_map.put(cur, sort_map.getOrDefault(cur, 0) + 1);
		}
		Collections.sort(ar, new Comparator<Integer>() {
			@Override
			public int compare(Integer i1, Integer i2) {
				int comp_freq = sort_map.get(i1).compareTo(sort_map.get(i2));
				int comp_value = i1.compareTo(i2);
				if (comp_freq == 0)
					return comp_value;
				else
					return comp_freq;
			}
		});
		System.out.println(sort_map);
		for (Integer i : res) {
			System.out.print(i + " ");
		}
	}
	
	public static void main(String[] args) {
		ArrayList<Integer> ar = new ArrayList<Integer>();
		for (int i=0;i<100;i++) {
			ar.add((int)(Math.random()*10));			
		}
		System.out.println(ar.toString());
		sortByFrequency(ar);
		System.out.println(ar.toString());
	}
}
