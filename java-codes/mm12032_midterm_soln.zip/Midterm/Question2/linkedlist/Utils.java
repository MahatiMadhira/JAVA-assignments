package linkedlist;

import java.util.Random;

public class Utils {
	public static String randomString(int length) {
		Random r = new Random();
		String s = "";
		for (int i=0;i<length;i++) {
			@SuppressWarnings("removal")
			Character c = new Character((char) ('a' + r.nextInt(26)));
			s = s + c;
		}
		return s;
	}
}
