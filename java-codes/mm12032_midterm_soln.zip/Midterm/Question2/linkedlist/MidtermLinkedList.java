package linkedlist;

import java.util.Comparator;
import java.util.Random;

public class MidtermLinkedList <M extends Comparable <M>>{

	private Node<M> head = null;
	private Node<M> tail = null;
	
	private MidtermLinkedList<M> merge(MidtermLinkedList<M> l1, 
										MidtermLinkedList<M> l2, Comparator <M> compMethod) {
		

		Node<M> nextHead = null;
		MidtermLinkedList<M> result = new MidtermLinkedList<M>();
		if (l1.getHead() == null) {
			return l2;
		}
		if (l2.getHead() == null) {
			return l1;
		}
		
		
		int res = 0;
		if(compMethod != null)
		{
			res = compMethod.compare(l1.getHead().getData(),l2.getHead().getData());
		}
		else
		{
			res = l1.getHead().getData().compareTo(l2.getHead().getData());
		}
		
		if (res >= 0) {
			nextHead = l2.getHead();	
			l2.setHead(nextHead.next);
			
			result = merge(l1, l2, compMethod);
			nextHead.next = result.getHead();
			result.setHead(nextHead);
			
		} else {
			nextHead = l1.getHead();
			l1.setHead(nextHead.next);
			result = merge(l2, l1, compMethod);
			nextHead.next = result.getHead();
			result.setHead(nextHead);
		}
		return result;
	}
	
	
	private Node<M> getMiddle(Node<M> head) {
		if (head == null)
            return null;
 
		Node<M> slow = head;
		Node<M> fast = head;
 
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
	}
	
	public MidtermLinkedList<M> sort(Comparator<M> compMethod) {
		Node<M> head = this.head;
		if ( (head == null) || (head.next == null)) {
			return this; 
		}
		
		Node<M> middle = getMiddle(head);
		Node<M> nextOfMiddle = middle.next;
		MidtermLinkedList<M> left;
		MidtermLinkedList<M> right = new MidtermLinkedList<M>();
		right.setHead(nextOfMiddle);
		right.setTail(this.getTail());
		
		middle.next = null;
		left = this;
		left.setHead(head);
		left.setTail(middle);
		left = left.sort(compMethod);
		right = right.sort(compMethod);
		MidtermLinkedList<M> ll = merge(left, right, compMethod);
		this.setHead(ll.getHead());
		this.setTail(ll.getTail());
		return ll;
	}
	
	public void addNode(M data) {
		Node<M> newNode = new Node<M>(data);
		if (this.head == null) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			tail = newNode;
		}
	}
	
	public Node<M> getHead() {
		return this.head;
	}
	
	public void setHead(Node<M> n) {
		this.head = n;
	}
	
	public Node <M>getTail() {
		return this.tail;
		
	}
	
	public void setTail(Node<M> n) {
		this.tail = n;
	}
	
	public String toString() {
		Node<M> current = head;
		String output = "";
		if (head == null) {
			return "[]";
		} else {
			while (current != null) {
				output += "-> " + current.toString();
				current = current.next;
			}
			return output;
		}
	}
	
	public static void main(String[] args) {
		Random r = new Random();
		MidtermLinkedList<Integer> mll = new MidtermLinkedList<Integer>();
		for (int i=0;i< 100;i++) {
			mll.addNode(r.nextInt(250));
		}
		System.out.println(mll.toString());
		
		MidtermLinkedList<Integer> mll2 = mll.sort(null);
		System.out.println("Initial sort with Integers: ");
		System.out.println(mll2.toString());
		
		System.out.println("Sorted Integers in Descending order: ");
		Comparator<Integer> desc = (Integer o1, Integer o2)->o2.compareTo(o1);
		
		MidtermLinkedList<Integer> mll2Desc = mll.sort(desc);
		System.out.println(mll2Desc.toString());
		

		MidtermLinkedList<String> mllStrings = new MidtermLinkedList<String>();
		for (int i=0;i< 10;i++) {
			mllStrings.addNode(Utils.randomString(r.nextInt(15)));
		}
		System.out.println(mllStrings.toString());
		MidtermLinkedList<String> mllStrings2 = mllStrings.sort(null);
		System.out.println(mllStrings2.toString());
		
		System.out.println("Comparing the lengths of the 2 Strings: ");
		
		Comparator<String> str_len = (String o1, String o2)-> Integer.compare(o1.length(), o2.length());

		MidtermLinkedList<String> str_len_res = mllStrings2.sort(str_len);
		System.out.println(str_len_res.toString());
	}
}
