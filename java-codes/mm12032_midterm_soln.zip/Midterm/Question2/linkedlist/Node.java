package linkedlist;

public class Node <M extends Comparable <M>>{
	/* the "data" field is just an Object? I should be able to make sure that the 
	 * "data" field can be a specific type that I specify for a Node object
	 */
	M data;
	Node <M> next;
	
	public Node(M data) {
		this.data = data;
		this.next = null;
	}
	
	public M getData() {
		return this.data;
	}
	
	public void setData(M data) {
		this.data = data;
	}
	
	public Node<M> getNext() {
		return this.next;
	}
	
	public void setNext(Node<M> next) {
		this.next = next;
	}
	
	public String toString() {
		return "Node: [" + this.data.toString() + "]";
	}
}
