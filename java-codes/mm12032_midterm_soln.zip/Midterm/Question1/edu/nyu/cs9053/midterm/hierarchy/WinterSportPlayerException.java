package edu.nyu.cs9053.midterm.hierarchy;

public class WinterSportPlayerException extends Exception{
	WinterSportPlayerException(String playerType)
	{
		super(playerType);
	}

}
