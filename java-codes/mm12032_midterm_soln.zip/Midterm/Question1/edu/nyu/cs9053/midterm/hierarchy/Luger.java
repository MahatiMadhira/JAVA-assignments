package edu.nyu.cs9053.midterm.hierarchy;

public class Luger extends Sledder {
	private String name;
    private int age;
    private String color;
    private int noOfPlayers; //unique to Luge
    
    public Luger()
    {
    	super();
    }

    public Luger(String name, int age, String color, int n)
    {
    	this.name = name;
    	this.age = age;
    	this.color = color;
    	this.noOfPlayers = n;
    }
    
    public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public String getSledColor()
    {
    	return color;
    }
    
    public int getPlayers()
    {
    	return noOfPlayers;
    }
    
    public String toString()
    {
    	return "Luger Name: "+name+" Age: "+age+" Sled color: "+color+" and No. of players :"+noOfPlayers ;
    }
    
    public boolean equals(Luger l)
    {
    	if(l.getAge() == getAge() && l.getSledColor() == getSledColor() && l.getPlayers() == getPlayers()) return true;
    	return false;
    }
}
