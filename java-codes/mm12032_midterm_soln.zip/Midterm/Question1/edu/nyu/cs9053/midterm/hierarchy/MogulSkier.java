package edu.nyu.cs9053.midterm.hierarchy;

public class MogulSkier extends Skier{
	private String name;
    private int age;
    private int skiLength;
    private int bumps; //unique to MogulSkier
    
    public MogulSkier(String name, int age, int l1, int n)
    {
    	this.name = name;
    	this.age = age;
    	this.skiLength = l1;
    	this.bumps = n;
    }

    public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public int getSkiLength()
    {
    	return skiLength;
    }
    
    public int getBumps()
    {
    	return bumps;
    }
    
    public String toString()
    {
    	return "Mogul Skier Name: "+name+" Age: "+age+" Ski length: "+skiLength+" and no of bumps on track :"+bumps;
    }

    public boolean equals(MogulSkier m)
    {
    	if(m.getAge() == getAge() && m.getSkiLength() == getSkiLength() && m.getBumps() == getBumps()) return true;
    	return false;
    }
}
