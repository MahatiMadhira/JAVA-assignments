package edu.nyu.cs9053.midterm.hierarchy;

public class Inheritance {
public static void main(String[] args) {
		
		Luger p1 = new Luger("Mahati", 23, "Black", 2);
		BobSledder p2 = new BobSledder("Amuktha", 22, "White", 13.5);
		MogulSkier p3 = new MogulSkier("Aayushi", 24, 5, 4);
		FigureSkater p4 = new FigureSkater("Tanmayi", 23, 20, "Pink");
		CrossCountrySkier p5 = new CrossCountrySkier("Chanakya", 25, 7, 3.4);
		Curler p6 = new Curler("Naveen", 24, 6, "Mahati");
		Curler p7 = new Curler("Srinu", 24, 5, "Mahati");
		
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
		System.out.println(p4.toString());
		System.out.println("Ski Pole Length for Cross Country Skater = "+p5.getPoleLength());
		System.out.println("Name of Skip Leader: "+p6.getSkipName());
		System.out.println("Do two curlers have same skip leader?");
		if(p6.getSkipName() == p7.getSkipName()) System.out.println("Yes: "+p6.getSkipName());
		else System.out.println("No they don't!");
		
	}

}
