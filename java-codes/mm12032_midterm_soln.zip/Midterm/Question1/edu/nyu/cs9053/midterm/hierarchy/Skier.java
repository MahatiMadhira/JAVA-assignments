package edu.nyu.cs9053.midterm.hierarchy;

abstract class Skier extends WinterSportPlayer{
	public abstract int getSkiLength();

}
