package edu.nyu.cs9053.midterm.hierarchy;

abstract class IceSkater extends WinterSportPlayer{
	public abstract int getSkateSize();

}
