package edu.nyu.cs9053.midterm.hierarchy;
import java.io.*;
import java.util.*;

import vehicles.Employee;
public abstract class WinterSportPlayer {

	public String getName() {
		
		return null;
	}
	
	public int getAge() {
		
		return -1;
	}
	
	public static WinterSportPlayer createPlayer(String playerType, String name, int age) throws WinterSportPlayerException{
		/* throw a WinterSportsPlayer exception if the parameter playerName does not match any possible WinterSportsPlayer objects
		 * that can be created.
		 */
		if(playerType.equals("BobSledder"))
		{
			BobSledder b = new BobSledder(name,age, "White", 13.5);
			return b;
		}
		
		if(playerType.equals("CrossCountrySkier"))
		{
			CrossCountrySkier c = new CrossCountrySkier(name,age, 7, 3.4);
			return c;
		}
		
		if(playerType.equals("MogulSkier"))
		{
			MogulSkier m = new MogulSkier(name,age, 5, 4);
			return m;
		}
		
		if(playerType.equals("Curler"))
		{
			Curler c = new Curler(name,age, 6, "Mahati");
			return c;
		}
		
		if(playerType.equals("FigureSkater"))
		{
			FigureSkater f = new FigureSkater(name,age, 20, "Pink");
			return f;
		}
		
		if(playerType.equals("Luger"))
		{
			Luger l = new Luger(name,age,"Blue",5);
			return l;
		}
		
		if(playerType.equals("SpeedSkater"))
		{
			SpeedSkater s = new SpeedSkater(name,age,35,20);
			return s;
		}
		else
		{
			throw new WinterSportPlayerException("Player Type: "+playerType+" does not exist!");
		}
		
	}
	
	public static ArrayList readPlayerFile(String filename) throws WinterSportPlayerException{
		/* here: read in the file players.txt and create an ArrayList containing all the WinterSportPlayers from the file.
		 * Catch any exceptions. 
		 */
		ArrayList<WinterSportPlayer> playerList = new ArrayList<WinterSportPlayer>();
		File f = new File(filename);
		String inString = null;
		
		
		try
		{
			FileInputStream fis=new FileInputStream(f);
			Scanner sc=new Scanner(fis);
			while(sc.hasNextLine()){
				inString = sc.nextLine(); 
				String[] inArray = inString.split(",");
				ArrayList<String> strList = new ArrayList<String>(
			            Arrays.asList(inArray));
				try {
					WinterSportPlayer p1 = createPlayer(strList.get(0), strList.get(1), Integer.parseInt(strList.get(2)));
					playerList.add(p1);
				}
				catch(WinterSportPlayerException w)
				{
					System.err.println(w);
				}
				
			}
				sc.close();
				fis.close();
		}catch (IOException e){
			System.err.println("File Cannot be found: " + f);
		}
		for(int i=0;i<playerList.size();i++)
		{
		System.out.println((i+1) + " " +playerList.get(i));
		}
		return playerList;
	}
	
	public static void main(String[] args) throws WinterSportPlayerException {

		readPlayerFile("players.txt");
	}
}
