package edu.nyu.cs9053.midterm.hierarchy;

abstract class Sledder extends WinterSportPlayer {
	public abstract String getSledColor();

}
