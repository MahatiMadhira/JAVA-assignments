package edu.nyu.cs9053.midterm.hierarchy;

public class FigureSkater extends IceSkater{
	private String name;
    private int age;
    private int skateSize;
    private String costumeColor; //unique to FigureSkating
	public FigureSkater(String name,int age, int size, String color)
	{
		this.name = name;
		this.age = age;
		this.skateSize = size;
		this.costumeColor = color;
	}
	
	public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public int getSkateSize()
    {
    	return skateSize;
    }
    
    public String getCostumeColor()
    {
    	return costumeColor;
    }
    
    public String toString()
    {
    	return "Figure Skater Name: "+name+" Age: "+age+" Skate size: "+skateSize+" and Costume Color :"+costumeColor;
    }

    public boolean equals(FigureSkater f)
    {
    	if(f.getAge() == getAge() && f.getSkateSize() == getSkateSize() && f.getCostumeColor() == getCostumeColor()) return true;
    	return false;
    }

}
