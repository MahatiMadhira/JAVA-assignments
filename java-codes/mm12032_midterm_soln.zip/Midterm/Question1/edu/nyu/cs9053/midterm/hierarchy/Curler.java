package edu.nyu.cs9053.midterm.hierarchy;

public class Curler extends IceSkater{
	private String name;
    private int age;
    private int skateSize;
    private String skipName; //unique to Curling
	public Curler(String name,int age, int size, String skipName)
	{
		this.name = name;
		this.age = age;
		this.skateSize = size;
		this.skipName = skipName;
	}
	
	public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public int getSkateSize()
    {
    	return skateSize;
    }
    
    public String getSkipName()
    {
    	return skipName;
    }
    
    public String toString()
    {
    	return "Curler Name: "+name+" Age: "+age+" Skate size: "+skateSize+" and Skip Name :"+skipName;
    }
    
    public boolean equals(Curler c)
    {
    	if(c.getAge() == getAge() && c.getSkateSize() == getSkateSize() && c.getSkipName() == getSkipName()) return true;
    	return false;
    }


}
