package edu.nyu.cs9053.midterm.hierarchy;

public class CrossCountrySkier extends Skier{
	private String name;
    private int age;
    private int skiLength;
    private double skiPoleLength; //unique to CrossCountrySkier
    
    public CrossCountrySkier(String name, int age, int l1, double l2)
    {
    	this.name = name;
    	this.age = age;
    	this.skiLength = l1;
    	this.skiPoleLength = l2;
    }

    public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public int getSkiLength()
    {
    	return skiLength;
    }
    
    public double getPoleLength()
    {
    	return skiPoleLength;
    }
    
    public String toString()
    {
    	return "Cross Country Skier Name: "+name+" Age: "+age+" Ski length: "+skiLength+" and Ski Pole Length :"+skiPoleLength ;
    }
    
    public boolean equals(CrossCountrySkier c)
    {
    	if(c.getAge() == getAge() && c.getSkiLength() == getSkiLength() && c.getPoleLength() == getPoleLength()) return true;
    	return false;
    }
}
