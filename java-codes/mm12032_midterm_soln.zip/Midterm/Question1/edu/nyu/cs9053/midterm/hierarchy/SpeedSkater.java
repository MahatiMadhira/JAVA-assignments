package edu.nyu.cs9053.midterm.hierarchy;

public class SpeedSkater extends IceSkater{
	private String name;
    private int age;
    private int skateSize;
    private int distance; //unique to SpeedSkating
	public SpeedSkater(String name,int age, int size, int dist)
	{
		this.name = name;
		this.age = age;
		this.skateSize = size;
		this.distance = dist;
	}
	
	public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public int getSkateSize()
    {
    	return skateSize;
    }
    
    public int getTrackDistance()
    {
    	return distance;
    }
    
    public String toString()
    {
    	return "Speed Skater Name: "+name+" Age: "+age+" Skate size: "+skateSize+" and track distance :"+distance;
    }
    
    public boolean equals(SpeedSkater s)
    {
    	if(s.getAge() == getAge() && s.getSkateSize() == getSkateSize() && s.getTrackDistance() == getTrackDistance()) return true;
    	return false;
    }

}
