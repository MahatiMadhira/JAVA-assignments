package edu.nyu.cs9053.midterm.hierarchy;

public class BobSledder extends Sledder{
	private String name;
    private int age;
    private String color;
    private double sledLength; //unique to BobSledder

    public BobSledder(String name, int age, String color, double l)
    {
    	this.name = name;
    	this.age = age;
    	this.color = color;
    	this.sledLength = l;
    }
    
    public String getName()
    {
    	return name;
    }
    
    public int getAge()
    {
    	return age;
    }
    
    public String getSledColor()
    {
    	return color;
    }
    
    public double getSledLength()
    {
    	return sledLength;
    }
    
    public String toString()
    {
    	return "Bob Sledder Name: "+name+" Age: "+age+" Sled color: "+color+" and sled length :"+sledLength ;
    }
    
    public boolean equals(BobSledder b)
    {
    	if(b.getAge() == getAge() && b.getSledColor() == getSledColor() && b.getSledLength() == getSledLength()) return true;
    	return false;
    }

}
