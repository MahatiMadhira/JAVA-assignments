package chat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

@SuppressWarnings("serial")
public class ChatServer extends JFrame implements Runnable {

    private static int WIDTH = 400;
    private static int HEIGHT = 300;
    private Map<String, DataOutputStream> clientOutputStreams;
    private JTextArea ta;
    private int clientNo = 0;

    public ChatServer() {
	super("Chat Server");
	this.setSize(ChatServer.WIDTH, ChatServer.HEIGHT);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	ta = new JTextArea();
	ta.setLocation(0, 0);
	ta.setSize(ChatServer.WIDTH, ChatServer.HEIGHT);
	ta.setEditable(false);
	JScrollPane scrollPane = new JScrollPane(ta);
	this.add(scrollPane);
	createMenu();
	this.setVisible(true);
	Thread t = new Thread(this);
	t.start();
    }

    private void createMenu() {
	JMenuBar menuBar = new JMenuBar();
	JMenu menu = new JMenu("File");
	JMenuItem exitItem = new JMenuItem("Exit");
	exitItem.addActionListener((e) -> System.exit(0));
	menu.add(exitItem);
	menuBar.add(menu);
	this.setJMenuBar(menuBar);
    }

    @Override
    public void run() {
	clientOutputStreams = new HashMap<String, DataOutputStream>();
	ServerSocket serverSocket = null;
	Socket client = null;
	DataOutputStream inputClient = null;
	try {
	    serverSocket = new ServerSocket(9898);
	    ta.append("Server started at " + new Date() + '\n');

	    while (true) {
		client = serverSocket.accept();
		clientNo++;
		inputClient = new DataOutputStream(client.getOutputStream());
		clientOutputStreams.put(clientNo + " :", inputClient);
		ta.append("Starting a new thread for client " + clientNo + "at" + new Date() + "\n");
		InetAddress group = client.getInetAddress();
		ta.append("Cleint " + clientNo + "'s host name is localhost " + "\n");
		ta.append("Cleint " + clientNo + "'s IP Address is " + group.getHostAddress() + "\n");
		new Thread(new ClientHandler(client, clientNo + " :")).start();
	    }
	} catch (IOException e) {
	    e.printStackTrace();
	    try {
		serverSocket.close();
		client.close();
		inputClient.close();
	    } catch (IOException ce) {
		ce.printStackTrace();
	    }
	} finally {
	    try {
		serverSocket.close();
		client.close();
		inputClient.close();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
    }

    @SuppressWarnings("rawtypes")
    public void broadcast(String name, String message) {

	for (Map.Entry mapElement : clientOutputStreams.entrySet()) {
	    if (!name.equalsIgnoreCase((String) mapElement.getKey())) {
		try {
		    DataOutputStream sendClient = (DataOutputStream) mapElement.getValue();
		    sendClient.writeUTF(message);
		    sendClient.flush();

		} catch (Exception ex) {
		    ex.printStackTrace();
		}
	    }

	}
    }

    public class ClientHandler implements Runnable {

	private Socket client;
	private String name;

	public ClientHandler(Socket client, String name) {
	    this.client = client;
	    this.name = name;
	}

	@SuppressWarnings("rawtypes")
	public void broadcast(String name, String message) {

	    for (Map.Entry mapElement : clientOutputStreams.entrySet()) {
		if (!name.equalsIgnoreCase((String) mapElement.getKey())) {
		    try {
			DataOutputStream sendClient = (DataOutputStream) mapElement.getValue();
			sendClient.writeUTF(message);
			sendClient.flush();

		    } catch (Exception ex) {
			ex.printStackTrace();
		    }
		}

	    }
	}

	public void run() {
	    DataInputStream outputClient = null;
	    try {
	    	outputClient = new DataInputStream(client.getInputStream());
		while (true) {
		    String input;
		    input = outputClient.readUTF();
		    input = name + " " + input;
		    broadcast(name, input);

		}
	    } catch (IOException e) {
		System.err.println("Client " + name + "'s connection has been terminated!");
		try {
			outputClient.close();
		} catch (IOException ce) {
		    ce.printStackTrace();
		}
	    } finally {
		try {
			outputClient.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
	    }
	}
    }

    @SuppressWarnings("unused")
    public static void main(String[] args) {
	ChatServer chatServer = new ChatServer();
    }
}