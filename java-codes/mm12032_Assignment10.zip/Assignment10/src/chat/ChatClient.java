package chat;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import javax.swing.*;

@SuppressWarnings("serial")
public class ChatClient extends JFrame implements Runnable {

   
    private static int WIDTH = 400;
    private static int HEIGHT = 300;
    static Thread t = null;
    DataOutputStream inputMessage = null;
    DataInputStream outputMessage = null;
    JTextField t1 = null;
    JTextArea ta = null;
    Socket socket = null;
    
    
    public ChatClient() {
	super("Chat Client");
	this.setLayout(new BorderLayout());
	this.setSize(ChatClient.WIDTH, ChatClient.HEIGHT);
	createMenu();
	ta = new JTextArea(30, 30);
	ta.setEditable(false);
	JScrollPane scrollPane = new JScrollPane(ta);
	
	this.add(scrollPane, BorderLayout.CENTER);
	t1 = new JTextField(30);
	t1.setEditable(false);
	t1.addActionListener(new TextFieldListener());
	this.add(t1, BorderLayout.SOUTH);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setVisible(true);

    }

    private void createMenu() {
	JMenuBar menuBar = new JMenuBar();
	JMenu menu = new JMenu("File");
	JMenuItem connectItem = new JMenuItem("Connect");
	JMenuItem exitItem = new JMenuItem("Exit");
	exitItem.addActionListener((e) -> System.exit(0));
	connectItem.addActionListener(new ConnectionListener());
	menu.add(connectItem);
	menu.add(exitItem);
	menuBar.add(menu);
	this.setJMenuBar(menuBar);
    }

    public void run() {
	while (true) {
	    try {
		String message = outputMessage.readUTF();
		ta.append(message + "\n");
	    } catch (Exception e) {
		e.printStackTrace();
		break;
	    }
	}
    }

    class ConnectionListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
	    try {
		socket = new Socket("localhost", 9898);
		ta.append("Connected to Server\n");
		outputMessage = new DataInputStream(socket.getInputStream());
		t.start();
		t1.setEditable(true);
	    } catch (Exception e1) {
		e1.printStackTrace();
		ta.append("connection Failure");
	    }

	}

    }

    class TextFieldListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
	    try {
		// Output stream to send data to the server
		inputMessage = new DataOutputStream(socket.getOutputStream());
	    } catch (Exception ex) {
	    	ta.append(ex.toString() + '\n');
	    }

	    try {
		if (t1.getText().trim() != "") {
		    String message = t1.getText().trim();
		    inputMessage.writeUTF(message);
		    inputMessage.flush();
		    ta.append(message + "\n");
		}

		t1.setText("");
	    } catch (Exception ex) {
		System.err.println(ex);
	    }
	}
    }

    public static void main(String[] args) {
	ChatClient chatClient = new ChatClient();
	try {
	    t = new Thread(chatClient);
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }
}