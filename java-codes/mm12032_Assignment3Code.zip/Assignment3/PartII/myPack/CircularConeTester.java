package myPack;

public class CircularConeTester {
	 public static void main(String[] args) {
	      
	       CircularCone c1 = new CircularCone(2.0, 3.0);
	       CircularCone c2 = new CircularCone();
	       CircularCone c3 = new CircularCone(1.5, 2.5);

	      
	       System.out.println("CircularCone 1 " + c1.getId() + ": r1=" + c1.getRadius() + ", h1=" + c1.getHeight() + " Slant 1="
	               + c1.getSlant() + ", Vol 1=" + c1.getVolume() + ", Area 1=" + c1.getArea());

	       System.out.println("CircularCone 2 " + c2.getId() + ": r2=" + c2.getRadius() + ", h2=" + c2.getHeight() + " Slant 2="
	               + c2.getSlant() + ", Vol 2=" + c2.getVolume() + ", Area 2=" + c2.getArea());
	       
	       System.out.println("CircularCone 3 " + c3.getId() + ": r3=" + c3.getRadius() + ", h3=" + c3.getHeight() + " Slant 3="
	               + c3.getSlant() + ", Vol 3=" + c3.getVolume() + ", Area 3=" + c3.getArea());
	   }

}
