package myPack;
public class CircularCone {
	 private static int nextId = 1;
	 private int id;
	 private double radius;
	 private double height;

	   
	   public CircularCone() {
		   
	       this.radius = 2.0;
	       this.height = 4.0;
	       this.id = nextId;

	       nextId += 1;
	   }

	  
	   public CircularCone(double radius, double height) {
	       this.radius=radius;
	       this.height=height;

	       this.id = nextId;

	       nextId += 1;
	   }

	 
	 
	   public double getRadius() {
	       return radius;
	   }

	  
	   public double getHeight() {
	       return height;
	   }

	  
	   public void setRadius(double radius) {
	       this.radius=radius;;
	   }

	  
	   public void setHeight(double height) {
	       this.height=height;
	   }

	  
	   public double getSlant() {
	       return (Math.pow((Math.pow(this.radius, 2)) + (Math.pow(this.height, 2)),0.5));
	   }
	   
	   public double getVolume() {
		   return ((Math.PI * this.radius * this.radius * this.height)/3);
	   }
	   
	   public double getArea() {
		   return (Math.PI * this.radius * (this.radius + getSlant()));
	   }
	   
	   public int getId() {
	       return id;
	   }
	   
	}



	
