
public class Dog {
        private int age;
        private String owner;
        private String breed;
        
        public Dog(int age, String owner, String breed)
        {
        	this.age=age;
        	this.owner=owner;
        	this.breed=breed;
        }
        public int getAge()
        {
        	return age;
        }
        public String getOwner()
        {
        	return owner;
        }
        public String getBreed()
        {
        	return breed;
        }
        public void setAge(int age)
        {
        	this.age=age;
        }
        public void setOwner(String owner)
        {
        	this.owner=owner;
        }
        public void setBreed(String breed)
        {
        	this.breed=breed;
        }
        
        public static boolean hasSameOwner(Dog d1, Dog d2)
        {
        	return d1.getOwner().equalsIgnoreCase(d2.getOwner());
        }
        
        public String toString()
        {
        	return this.getBreed()+": Owner : "+this.getOwner()+", Age: "+this.getAge();
        }
        
        public static double avgAge(Dog[] dogs)
        {
        	double s=0;
        	for(Dog d: dogs)
        	{
        		s+=d.age;
        	}
        	return s/dogs.length;
        }
        
        
        public static void main(String[] args) {
                
                Dog[] dogs = new Dog[5];
                dogs[0] = new Dog(4, "Stephen Colbert", "Boxer");
                dogs[1] = new Dog(8, "Dexter Morgan", "Corgi");
                dogs[2] = new Dog(3, "Mahati Madhira", "Golden Retreiver");
                dogs[3] = new Dog(6, "Mahati Madhira" , "Pit Bull");
                dogs[4] = new Dog(2, "Robert Downey", "Husky");
                
                System.out.println("Details of all dogs:");
                for(int i=0;i<dogs.length;i++)
                {
                	System.out.println(dogs[i]);
                }
                System.out.println();
                if(Dog.hasSameOwner(dogs[2],dogs[3]))
                	System.out.println(dogs[2].getBreed()+" and "+dogs[3].getBreed()+" have the same owner "+dogs[2].getOwner());
                else
                	System.out.println(dogs[2].getBreed()+" and "+dogs[3].getBreed()+" do not have the same owner ");
                System.out.println();
                
                System.out.println("The average age of all dogs = "+Dog.avgAge(dogs));
                
        }
}