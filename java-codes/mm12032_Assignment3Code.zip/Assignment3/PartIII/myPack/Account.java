package myPack; 
public class Account {

	private int id;
	private static int account_count = 0;
    private double balance;
    

    public Account() 
    {
    	balance = 0;
        id = ++account_count;
    }

    public Account(double startingBalance) 
    {
    	balance = startingBalance;
        id = ++account_count;
    }

    public boolean withdraw(double amount) 
    {
        if(amount > balance) 
            return false;
        else
        	{
        		balance -= amount;
        		return true;
        	}
    }
    
    public int getId() 
    {
        return id;
    }

    public double getBalance() 
    {
        return balance;
    }

    public void deposit(double amount) 
    {
        balance += amount;
    }

    
}

