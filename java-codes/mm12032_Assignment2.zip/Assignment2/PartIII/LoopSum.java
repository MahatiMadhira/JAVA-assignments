import java.util.*;
public class LoopSum {

	public static int sum200() {
		int i;
		int sum=0;
		for(i=1;i<=200;i++)
		{
			if(i%5==0)
				sum+=i;
		}
	
		return sum;
	}
	
	public static int sumNX(int N, int X) {
		int sum=0,i;
		for(i=1;i<=N;i++)
		{
			if(i%X==0)
				sum+=i;
		}
		
		
		return sum;
	}
	
	public static void main(String[] args) {
		int s1=sum200();
		int s2=sumNX(100,9);
		
		System.out.println("Sum of integers between 1 and 200 divisible by 5 = "+s1);
		System.out.println("Sum of integers between 1 and 100 divisible by 9 = "+s2);
		
		
	}
	
}
