
public class Factorial {

	public static void main(String[] args) {
		int val = 10,i,f=1;
		for(i=val;i>0;i--)
		{
			f=f*i;
		}
		
		System.out.println("Factorial of "+val+" = "+f);
	}
}
