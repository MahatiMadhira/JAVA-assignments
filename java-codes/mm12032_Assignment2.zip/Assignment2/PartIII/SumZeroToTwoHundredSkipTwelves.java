
/* You're going to sum up the numbers 0 to 100 but you are
 * going to skip any number divisible by 15. 
 */
public class SumZeroToTwoHundredSkipTwelves {

	public static void main(String[] args) {
		
		// you can use any kind of loop you want
		// have a counter that counts from 0 to 200
		
		int i,sum1=0,sum2=0;
		for(i=0;i<=200;i++)
		{
			if(i%12!=0)
				sum1+=i;
		}
		System.out.println("Sum 1 = "+sum1);
		for(i=0;i<=200;i++)
		{
			if(i%12==0)
				continue;
			sum2+=i;
		}
		System.out.println("Sum 2 = "+sum2);
		// the first loop has the structure of 
		// if (counter is not divisible by 12)
		// then
		//    sum += counter;
		// the second loop has the structure of:
		// if (counter is divisible by 12)
		// then
		//  continue
		// and then it adds the counter to the sum if that condition does not execute
		
	}
}

