
public class FindIndex {

	public static void main(String[] args) {
		int[] intArray = {5, 3, 7, 10 , 15, 22, 60, 12, 45};
		int i;
		for(i=0;i<intArray.length;i++)
		{
			if(intArray[i]>20)
			{
				System.out.println("Index of first element > 20 = "+i);
				break;
			}
			
		}
		

	}

}
