
public class ArrayStats {

	public static void main(String[] args) {
		int[] intArray = new int[50];
		
		int smallestValue=intArray[0];
		int largestValue=intArray[0];
		double meanAverage=0;
		int sum=0;
		
		/* initialize the source Array */
		for (int i = 0;i < intArray.length; i++) {
			intArray[i] = (int)(Math.random()*100);
		}
		for(int i=1;i<intArray.length;i++)
		{
			if(smallestValue>intArray[i])
				smallestValue=intArray[i];
			if(largestValue<intArray[i])
				largestValue=intArray[i];
		}
		for(int i=0;i<intArray.length;i++)
		{
			sum+=intArray[i];
			meanAverage=sum/(intArray.length);
		}
		
		System.out.println("Smallest value in the array is " + 
							smallestValue);
		System.out.println("Largest value in the array is " + 
							largestValue);
		System.out.println("Mean average value of array elements is " + 
							meanAverage);
	}
}
