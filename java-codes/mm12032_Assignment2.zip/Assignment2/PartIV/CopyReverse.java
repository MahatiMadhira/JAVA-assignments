
public class CopyReverse {

	public static void main(String[] args) {
		
		int[] sourceArray = new int[50];
		int[] destArray = new int[50];
		
		/* initialize the source Array */
		for (int i = 0;i < sourceArray.length; i++) {
			sourceArray[i] = (int)(Math.random()*100);
		}
		for(int i=0;i<50;i++)
		{
			destArray[i]=sourceArray[50-i-1];
		}
		System.out.println("Source Array:");
		for(int i=0;i<50;i++)
		{
			System.out.println(" "+sourceArray[i]);
		}
		System.out.println("Destination Array:");
		for(int i=0;i<50;i++)
		{
			System.out.println(" "+destArray[i]);
		}
		
		/* destArray should have the contents of sourceArary
		 * but in reverse, eg:
		 * sourceArray[0] should have the same value of 
		 * destArray[destArray.length-1]
		 * sourceArray[1] should have the same value of 
		 * destArray[destArray.length-2]
		 * 
		 * and so on
		 */
	}
}
