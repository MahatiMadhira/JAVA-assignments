
public class DisplayInRows {

	static final int ROW_LENGTH = 20;
	
	public static void main(String[] args) {
		
		int[] intArray = new int[100];
		
		for (int i=0;i< intArray.length;i++) {
			intArray[i] = (int)(Math.random()*100);
		}
		for (int i=0,c=0;i< intArray.length;i++)
		{
			if(c==ROW_LENGTH)
			{
				System.out.println();
				c=0;
			}
			else
			{
				System.out.print(intArray[i]+" ");
				c++;
			}
		}
	}
}
