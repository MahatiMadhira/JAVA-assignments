
public class DragCalculator {

	public static double calculateDrag(double radius, double rho, double cd, double v0, double v1) 
	{
		double A;
		double pi = Math.PI;
		A=pi*radius*radius;
		double dragDifference = 0;
		dragDifference = 0.5 * cd * rho * A * ((v1*v1)-(v0*v0));
		return dragDifference;
	}
	
	public static void main(String[] args) {
		double result = calculateDrag(1.5,1.2,0.5,15,25);
		System.out.println("Calculated drag value = "+result);
		
	}
}
