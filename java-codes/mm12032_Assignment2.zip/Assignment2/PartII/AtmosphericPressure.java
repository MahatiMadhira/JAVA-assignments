import java.util.*;
public class AtmosphericPressure {

	public static double getPressureDifference(double h0, double h1) {
		double e = Math.E; // this is e
		double p0,p1;
		p0 = 101.325 * (Math.pow(e,((Math.log(0.88)/1000)*h0)));
		p1 = 101.325 * (Math.pow(e,((Math.log(0.88)/1000)*h1)));
		
		double diff = p0-p1;
		return diff;
	}
	
	public static void main(String[] args) {
		
		double h0=0;
		double h1=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter initial height h0:");
		h0 = sc.nextDouble();
		System.out.println("Enter final height h1:");
		h1 = sc.nextDouble();
		
		double pressureDifference=getPressureDifference(h0,h1);
		
		// Math.log(d) returns the natural log of d (ln d)
		
		// if the wind chill is valid:
		System.out.println("The difference in pressure between " + h0 + 
							"m and " + h1 + "m is " + pressureDifference + " kPal");
	}
}
