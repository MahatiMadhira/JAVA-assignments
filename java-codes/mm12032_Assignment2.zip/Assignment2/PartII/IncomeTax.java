import java.util.*;

public class IncomeTax {

	public static float calculateTax(float income) {
		// this is really only valid for income greater than 0.
		// but for income less than 0, the tax will be 0.
		double t=0;
		if(income>0 && income<=9950)
			t=0.1*income;
		else if(income>9950 && income<=40525)
			t=0.1*9950 + (income-9950)*0.12;
		else if(income>40525 && income<=86375)
			t=0.1*9950 + (40525-9950)*0.12 + (income-40525)*0.22;
		else if(income>86375 && income<=164925)
			t=0.1*9950 + (40525-9950)*0.12 + (86375-40525)*0.22+
				(income-86375)*0.24;
		else if(income>164925 && income<=209425)
			t=0.1*9950 + (40525-9950)*0.12 + (86375-40525)*0.22+
				(164925-86375)*0.24 + (income-164925)*0.32;
		else if(income>209425 && income<=523600)
			t=0.1*9950 + (40525-9950)*0.12 + (86375-40525)*0.22+
				(164925-86375)*0.24 + (209425-164925)*0.32 + (income-209425)*0.35;
		else
			t=0.1*9950 + (40525-9950)*0.12 + (86375-40525)*0.22+
				(164925-86375)*0.24 + (209425-164925)*0.32 + (523600-209425)*0.35
				+(income-523600)*0.37;
		
		return (float) t;
	}
	
	public static void main(String[] args) {
		
		/* you probably want to use user input for the
		 * income using Scanner because you will have to convert
		 * a command line argument to an float, and we haven't
		 * gotten to string parsing yet
		 * 
		 * But you can also just set the "year" variable
		 * to whatever you want in the code, and that's fine too
		 */
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the income:");
		int income = sc.nextInt() ;
		float tax = calculateTax(income);
		
		// if the digits are greater than zero print this out:
		System.out.println("The income tax for the income " + income + " is " 
		+ tax);
		
	}
}
